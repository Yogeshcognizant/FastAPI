#!/bin/bash

# Teams Zoho Bot Deployment Script
set -e

PROJECT_ID="teams-zoho-integration"
REGION="us-central1"
SERVICE_NAME="teams-bot"

echo "🚀 Starting deployment of Teams Zoho Bot..."

# Set project
gcloud config set project $PROJECT_ID

# Enable required APIs if not already enabled
echo "📋 Enabling required APIs..."
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable aiplatform.googleapis.com
gcloud services enable secretmanager.googleapis.com

# Build and deploy using Cloud Build
echo "🔨 Building and deploying with Cloud Build..."
gcloud builds submit --config=deployment/cloudbuild.yaml .

# Get the service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

echo "✅ Deployment completed successfully!"
echo "🌐 Service URL: $SERVICE_URL"
echo "📋 Health Check: $SERVICE_URL/health"
echo "🤖 Teams Endpoint: $SERVICE_URL/api/messages"

# Test health endpoint
echo "🔍 Testing health endpoint..."
curl -f "$SERVICE_URL/health" && echo "✅ Health check passed!" || echo "❌ Health check failed!"

echo ""
echo "📝 Next Steps:"
echo "1. Configure your Teams app with endpoint: $SERVICE_URL/api/messages"
echo "2. Update secrets in Secret Manager with your actual credentials"
echo "3. Test the bot in Microsoft Teams"
echo ""
echo "🔧 To update secrets:"
echo "gcloud secrets versions add zoho-client-id --data-file=<your-file>"
echo "gcloud secrets versions add zoho-client-secret --data-file=<your-file>"
echo "gcloud secrets versions add teams-app-id --data-file=<your-file>"
echo "gcloud secrets versions add teams-app-password --data-file=<your-file>"