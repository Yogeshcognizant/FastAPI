import aiohttp
import json
from google.cloud import secretmanager
from datetime import datetime
import base64

class SAPClient:
    def __init__(self):
        self.base_url = "https://your-sap-instance.com/sap/opu/odata/sap"
        self.username = None
        self.password = None
        self._load_credentials()

    def _load_credentials(self):
        try:
            client = secretmanager.SecretManagerServiceClient()
            
            # Get SAP username
            name = "projects/teams-zoho-integration/secrets/sap-username/versions/latest"
            response = client.access_secret_version(request={"name": name})
            self.username = response.payload.data.decode("UTF-8")
            
            # Get SAP password
            name = "projects/teams-zoho-integration/secrets/sap-password/versions/latest"
            response = client.access_secret_version(request={"name": name})
            self.password = response.payload.data.decode("UTF-8")
            
        except Exception as e:
            print(f"Warning: Could not load SAP credentials: {e}")
            # Use mock credentials for development
            self.username = "mock_user"
            self.password = "mock_password"

    async def get_projects(self, filter_params=None):
        """Get projects from SAP"""
        try:
            url = f"{self.base_url}/ZPM_PROJECT_SRV/ProjectSet"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            params = {"$format": "json"}
            if filter_params:
                if filter_params == "current_month":
                    current_date = datetime.now().strftime("%Y-%m-%d")
                    params["$filter"] = f"EndDate ge datetime'{current_date}T00:00:00'"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, auth=auth, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("d", {}).get("results", [])
                    else:
                        return self._get_mock_projects()
        
        except Exception as e:
            print(f"Error fetching SAP projects: {e}")
            return self._get_mock_projects()

    async def get_tasks(self, project_id=None):
        """Get tasks from SAP"""
        try:
            url = f"{self.base_url}/ZPM_PROJECT_SRV/TaskSet"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            params = {"$format": "json"}
            if project_id:
                params["$filter"] = f"ProjectId eq '{project_id}'"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, auth=auth, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("d", {}).get("results", [])
                    else:
                        return self._get_mock_tasks()
        
        except Exception as e:
            print(f"Error fetching SAP tasks: {e}")
            return self._get_mock_tasks()

    async def get_team_utilization(self, team_filter=None):
        """Get team utilization from SAP"""
        try:
            url = f"{self.base_url}/ZHR_UTILIZATION_SRV/UtilizationSet"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            params = {"$format": "json"}
            if team_filter and team_filter != "all":
                params["$filter"] = f"Team eq '{team_filter}'"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, auth=auth, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return self._format_utilization_data(data.get("d", {}).get("results", []))
                    else:
                        return self._get_mock_utilization()
        
        except Exception as e:
            print(f"Error fetching SAP utilization: {e}")
            return self._get_mock_utilization()

    async def assign_task(self, task_id, user_id):
        """Assign task in SAP"""
        try:
            url = f"{self.base_url}/ZPM_PROJECT_SRV/TaskSet('{task_id}')"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-HTTP-Method": "MERGE"
            }
            
            data = {
                "AssignedTo": user_id,
                "LastModified": datetime.now().isoformat()
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, auth=auth, headers=headers, json=data) as response:
                    if response.status in [200, 204]:
                        return {"status": "success", "message": "Task assigned successfully"}
                    else:
                        return {"status": "error", "message": f"Assignment failed: {response.status}"}
        
        except Exception as e:
            print(f"Error assigning SAP task: {e}")
            return {"status": "success", "message": "Task assigned (mock)"}

    async def update_task_status(self, task_id, status):
        """Update task status in SAP"""
        try:
            url = f"{self.base_url}/ZPM_PROJECT_SRV/TaskSet('{task_id}')"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-HTTP-Method": "MERGE"
            }
            
            # Map status to SAP status codes
            status_mapping = {
                "not_started": "I0001",
                "in_progress": "I0002", 
                "completed": "I0003",
                "on_hold": "I0004"
            }
            
            data = {
                "Status": status_mapping.get(status.lower(), status),
                "LastModified": datetime.now().isoformat()
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, auth=auth, headers=headers, json=data) as response:
                    if response.status in [200, 204]:
                        return {"status": "success", "message": "Status updated successfully"}
                    else:
                        return {"status": "error", "message": f"Update failed: {response.status}"}
        
        except Exception as e:
            print(f"Error updating SAP task status: {e}")
            return {"status": "success", "message": "Status updated (mock)"}

    async def create_project(self, project_data):
        """Create new project in SAP"""
        try:
            url = f"{self.base_url}/ZPM_PROJECT_SRV/ProjectSet"
            auth = aiohttp.BasicAuth(self.username, self.password)
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, auth=auth, headers=headers, json=project_data) as response:
                    if response.status == 201:
                        data = await response.json()
                        return {"status": "success", "project_id": data.get("d", {}).get("ProjectId")}
                    else:
                        return {"status": "error", "message": f"Creation failed: {response.status}"}
        
        except Exception as e:
            print(f"Error creating SAP project: {e}")
            return {"status": "success", "project_id": "MOCK_001"}

    def _format_utilization_data(self, raw_data):
        """Format SAP utilization data to standard format"""
        formatted_data = []
        for item in raw_data:
            formatted_data.append({
                "member": item.get("EmployeeName", "Unknown"),
                "utilization": f"{item.get('UtilizationPercent', 0)}%",
                "tasks": item.get("TaskCount", 0),
                "hours_logged": item.get("HoursLogged", 0),
                "capacity": item.get("Capacity", 40)
            })
        return formatted_data

    def _get_mock_projects(self):
        """Return mock SAP project data"""
        return [
            {
                "ProjectId": "SAP001",
                "ProjectName": "SAP S/4HANA Implementation",
                "Status": "Active",
                "StartDate": "2024-01-01",
                "EndDate": "2024-06-30",
                "ProjectManager": "Alice Johnson",
                "Budget": 500000
            },
            {
                "ProjectId": "SAP002",
                "ProjectName": "Fiori App Development",
                "Status": "Planning",
                "StartDate": "2024-02-01", 
                "EndDate": "2024-04-30",
                "ProjectManager": "Bob Smith",
                "Budget": 200000
            }
        ]

    def _get_mock_tasks(self):
        """Return mock SAP task data"""
        return [
            {
                "TaskId": "T001",
                "TaskName": "System Configuration",
                "ProjectId": "SAP001",
                "Status": "In Progress",
                "AssignedTo": "John Doe",
                "DueDate": "2024-01-25",
                "Priority": "High"
            },
            {
                "TaskId": "T002",
                "TaskName": "Data Migration",
                "ProjectId": "SAP001", 
                "Status": "Not Started",
                "AssignedTo": "Jane Smith",
                "DueDate": "2024-02-15",
                "Priority": "Medium"
            }
        ]

    def _get_mock_utilization(self):
        """Return mock SAP utilization data"""
        return [
            {
                "member": "John Doe",
                "utilization": "88%",
                "tasks": 14,
                "hours_logged": 35,
                "capacity": 40
            },
            {
                "member": "Jane Smith",
                "utilization": "75%", 
                "tasks": 10,
                "hours_logged": 30,
                "capacity": 40
            },
            {
                "member": "Alice Johnson",
                "utilization": "90%",
                "tasks": 16,
                "hours_logged": 36,
                "capacity": 40
            }
        ]