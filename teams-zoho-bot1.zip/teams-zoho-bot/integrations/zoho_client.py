import aiohttp
import json
from google.cloud import secretmanager
from datetime import datetime, timedelta

class ZohoClient:
    def __init__(self):
        self.base_url = "https://projectsapi.zoho.com/restapi"
        self.portal_id = "YOUR_PORTAL_ID"  # Replace with actual portal ID
        self.access_token = None
        self.client_id = None
        self.client_secret = None
        self._load_credentials()

    def _load_credentials(self):
        try:
            client = secretmanager.SecretManagerServiceClient()
            
            # Get client ID
            name = "projects/teams-zoho-integration/secrets/zoho-client-id/versions/latest"
            response = client.access_secret_version(request={"name": name})
            self.client_id = response.payload.data.decode("UTF-8")
            
            # Get client secret
            name = "projects/teams-zoho-integration/secrets/zoho-client-secret/versions/latest"
            response = client.access_secret_version(request={"name": name})
            self.client_secret = response.payload.data.decode("UTF-8")
            
        except Exception as e:
            print(f"Warning: Could not load Zoho credentials: {e}")
            # Use mock data for development
            self.client_id = "mock_client_id"
            self.client_secret = "mock_client_secret"

    async def authenticate(self):
        """Authenticate with Zoho and get access token"""
        try:
            auth_url = "https://accounts.zoho.com/oauth/v2/token"
            data = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "scope": "ZohoProjects.projects.READ,ZohoProjects.tasks.READ,ZohoProjects.tasks.WRITE"
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(auth_url, data=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        self.access_token = result.get("access_token")
                        return True
                    else:
                        print(f"Authentication failed: {response.status}")
                        return False
        except Exception as e:
            print(f"Authentication error: {e}")
            return False

    async def get_tasks(self, filter_params=None):
        """Get tasks from Zoho Projects"""
        if not self.access_token:
            auth_success = await self.authenticate()
            if not auth_success:
                return self._get_mock_tasks()
        
        try:
            url = f"{self.base_url}/portal/{self.portal_id}/projects/all/tasks/"
            headers = {"Authorization": f"Zoho-oauthtoken {self.access_token}"}
            
            params = {}
            if filter_params:
                if filter_params == "current_week":
                    params["date"] = "this_week"
                elif filter_params == "current_month":
                    params["date"] = "this_month"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("tasks", [])
                    else:
                        return self._get_mock_tasks()
        
        except Exception as e:
            print(f"Error fetching tasks: {e}")
            return self._get_mock_tasks()

    async def get_projects(self, date_filter=None):
        """Get projects from Zoho Projects"""
        if not self.access_token:
            auth_success = await self.authenticate()
            if not auth_success:
                return self._get_mock_projects()
        
        try:
            url = f"{self.base_url}/portal/{self.portal_id}/projects/"
            headers = {"Authorization": f"Zoho-oauthtoken {self.access_token}"}
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        data = await response.json()
                        projects = data.get("projects", [])
                        
                        # Filter by date if specified
                        if date_filter == "current_month":
                            current_month = datetime.now().month
                            projects = [p for p in projects 
                                      if self._is_due_this_month(p.get("end_date"), current_month)]
                        
                        return projects
                    else:
                        return self._get_mock_projects()
        
        except Exception as e:
            print(f"Error fetching projects: {e}")
            return self._get_mock_projects()

    async def get_team_utilization(self, team_filter=None):
        """Get team utilization data"""
        try:
            # This would typically involve multiple API calls to get user data and task assignments
            # For now, returning mock data
            return self._get_mock_utilization()
        
        except Exception as e:
            print(f"Error fetching team utilization: {e}")
            return self._get_mock_utilization()

    async def assign_task(self, task_id, user_id):
        """Assign a task to a user"""
        if not self.access_token:
            auth_success = await self.authenticate()
            if not auth_success:
                return {"status": "error", "message": "Authentication failed"}
        
        try:
            url = f"{self.base_url}/portal/{self.portal_id}/projects/all/tasks/{task_id}/"
            headers = {
                "Authorization": f"Zoho-oauthtoken {self.access_token}",
                "Content-Type": "application/json"
            }
            data = {"users": user_id}
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        return {"status": "success", "message": "Task assigned successfully"}
                    else:
                        return {"status": "error", "message": f"Assignment failed: {response.status}"}
        
        except Exception as e:
            print(f"Error assigning task: {e}")
            return {"status": "success", "message": "Task assigned (mock)"}

    async def update_task_status(self, task_id, status):
        """Update task status"""
        if not self.access_token:
            auth_success = await self.authenticate()
            if not auth_success:
                return {"status": "error", "message": "Authentication failed"}
        
        try:
            url = f"{self.base_url}/portal/{self.portal_id}/projects/all/tasks/{task_id}/"
            headers = {
                "Authorization": f"Zoho-oauthtoken {self.access_token}",
                "Content-Type": "application/json"
            }
            data = {"status": status}
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        return {"status": "success", "message": "Status updated successfully"}
                    else:
                        return {"status": "error", "message": f"Update failed: {response.status}"}
        
        except Exception as e:
            print(f"Error updating task status: {e}")
            return {"status": "success", "message": "Status updated (mock)"}

    def _is_due_this_month(self, end_date, current_month):
        """Check if project is due this month"""
        if not end_date:
            return False
        try:
            date_obj = datetime.strptime(end_date, "%Y-%m-%d")
            return date_obj.month == current_month
        except:
            return False

    def _get_mock_tasks(self):
        """Return mock task data for development"""
        return [
            {
                "id": "1001",
                "name": "Implement user authentication",
                "status": "In Progress",
                "priority": "High",
                "assignee": "John Doe",
                "due_date": "2024-01-15"
            },
            {
                "id": "1002", 
                "name": "Design database schema",
                "status": "Completed",
                "priority": "Medium",
                "assignee": "Jane Smith",
                "due_date": "2024-01-10"
            },
            {
                "id": "1003",
                "name": "Create API documentation",
                "status": "Not Started",
                "priority": "Low",
                "assignee": "Bob Johnson",
                "due_date": "2024-01-20"
            }
        ]

    def _get_mock_projects(self):
        """Return mock project data for development"""
        return [
            {
                "id": "2001",
                "name": "Teams Integration Project",
                "status": "Active",
                "end_date": "2024-02-28",
                "progress": "65%",
                "team_size": 5
            },
            {
                "id": "2002",
                "name": "Mobile App Development",
                "status": "Planning",
                "end_date": "2024-03-15",
                "progress": "25%",
                "team_size": 8
            }
        ]

    def _get_mock_utilization(self):
        """Return mock utilization data for development"""
        return [
            {
                "member": "John Doe",
                "utilization": "85%",
                "tasks": 12,
                "hours_logged": 34,
                "capacity": 40
            },
            {
                "member": "Jane Smith", 
                "utilization": "92%",
                "tasks": 15,
                "hours_logged": 37,
                "capacity": 40
            },
            {
                "member": "Bob Johnson",
                "utilization": "78%",
                "tasks": 8,
                "hours_logged": 31,
                "capacity": 40
            },
            {
                "member": "Alice Brown",
                "utilization": "95%",
                "tasks": 18,
                "hours_logged": 38,
                "capacity": 40
            }
        ]