# Teams Zoho/SAP Integration Bot

Microsoft Teams AI assistant that integrates with Zoho Projects and SAP using Google Cloud Platform and Vertex AI.

## Features

- **Natural Language Processing**: Query projects and tasks using natural language
- **Zoho Projects Integration**: List tasks, projects, and team utilization
- **SAP Integration**: Access SAP project data and workflows  
- **Teams Adaptive Cards**: Rich interactive UI in Microsoft Teams
- **Meeting Scheduling**: Schedule meetings directly from Teams
- **Task Management**: Assign tasks and update statuses
- **Team Analytics**: View team utilization and performance metrics

## Architecture

```
Teams Client → Cloud Run (Bot) → Vertex AI → Zoho/SAP APIs
                     ↓
              Secret Manager (Credentials)
                     ↓
              Cloud SQL/Firestore (Cache)
```

## Quick Start

### 1. GCP Setup

```bash
# Clone the repository
git clone <repository-url>
cd teams-zoho-bot

# Make setup script executable
chmod +x gcp-setup/setup.sh

# Run GCP setup
./gcp-setup/setup.sh
```

### 2. Configure Secrets

Update the following secrets in Google Secret Manager:

```bash
# Zoho credentials
gcloud secrets versions add zoho-client-id --data-file=<your-zoho-client-id>
gcloud secrets versions add zoho-client-secret --data-file=<your-zoho-client-secret>

# Teams credentials  
gcloud secrets versions add teams-app-id --data-file=<your-teams-app-id>
gcloud secrets versions add teams-app-password --data-file=<your-teams-app-password>

# SAP credentials
gcloud secrets versions add sap-username --data-file=<your-sap-username>
gcloud secrets versions add sap-password --data-file=<your-sap-password>
```

### 3. Deploy to Cloud Run

```bash
# Build and deploy using Cloud Build
gcloud builds submit --config=deployment/cloudbuild.yaml .

# Or deploy to App Engine
gcloud app deploy deployment/app.yaml
```

### 4. Configure Teams App

1. Register bot in Azure Bot Service
2. Set messaging endpoint to your Cloud Run URL: `https://your-service-url/api/messages`
3. Install app in Microsoft Teams

## Usage Examples

### Natural Language Queries

- "List all tasks"
- "Show projects due this month" 
- "Team utilization report"
- "Assign task 1001 to @john"
- "Schedule meeting for tomorrow 2pm"

### Adaptive Card Actions

- Update task status
- Assign tasks to team members
- View project details
- Schedule meetings

## Configuration

### Zoho Projects Setup

1. Create Zoho OAuth app
2. Get client ID and secret
3. Update `PORTAL_ID` in `integrations/zoho_client.py`

### SAP Setup

1. Configure SAP OData services
2. Update base URL in `integrations/sap_client.py`
3. Set up authentication credentials

### Vertex AI Setup

```python
# Run agent setup
python vertex-ai/agent_config.py
```

## Development

### Local Development

```bash
# Install dependencies
pip install -r teams-bot/requirements.txt

# Set environment variables
export PROJECT_ID=teams-zoho-integration
export GOOGLE_APPLICATION_CREDENTIALS=path/to/service-account.json

# Run locally
python teams-bot/app.py
```

### Testing

```bash
# Test health endpoint
curl http://localhost:8000/health

# Test message endpoint
curl -X POST http://localhost:8000/api/messages \
  -H "Content-Type: application/json" \
  -d '{"type": "message", "text": "list tasks", "from": {"id": "test-user"}}'
```

## API Endpoints

- `POST /api/messages` - Teams bot messages
- `GET /health` - Health check

## Environment Variables

- `PROJECT_ID` - GCP project ID
- `PORT` - Server port (default: 8000)

## Security

- OAuth 2.0 authentication with Zoho/SAP
- Secure credential storage in Secret Manager
- Role-based access control
- HTTPS encryption

## Monitoring

- Cloud Logging for application logs
- Cloud Monitoring for metrics
- Health checks for availability

## Troubleshooting

### Common Issues

1. **Authentication Errors**: Check secret manager credentials
2. **API Timeouts**: Increase timeout values in client configurations
3. **Teams Connection**: Verify bot registration and endpoint URL

### Logs

```bash
# View Cloud Run logs
gcloud logs read --service=teams-bot

# View build logs
gcloud builds log <BUILD_ID>
```

## Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Test thoroughly
5. Submit pull request

## License

MIT License - see LICENSE file for details