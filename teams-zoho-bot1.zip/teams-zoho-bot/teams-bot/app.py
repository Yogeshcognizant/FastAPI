from flask import Flask, request, jsonify
import asyncio
import json
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vertex_ai.nlp_processor import NLPProcessor
from integrations.zoho_client import ZohoClient
from integrations.sap_client import SAPClient

app = Flask(__name__)

class TeamsBot:
    def __init__(self):
        self.nlp_processor = NLPProcessor()
        self.zoho_client = ZohoClient()
        self.sap_client = SAPClient()

    async def process_message(self, message, user_id):
        # Process with Vertex AI
        intent, entities = await self.nlp_processor.process_message(message)
        
        # Handle different intents
        if intent == "list_tasks":
            response = await self.handle_list_tasks(entities)
        elif intent == "show_projects":
            response = await self.handle_show_projects(entities)
        elif intent == "team_utilization":
            response = await self.handle_team_utilization(entities)
        elif intent == "assign_task":
            response = await self.handle_assign_task(entities)
        elif intent == "schedule_meeting":
            response = await self.handle_schedule_meeting(entities)
        else:
            response = self.create_help_card()
        
        return response

    async def handle_list_tasks(self, entities):
        try:
            tasks = await self.zoho_client.get_tasks(entities.get('filter'))
            return self.create_tasks_card(tasks)
        except Exception as e:
            return self.create_error_card(f"Error fetching tasks: {str(e)}")

    async def handle_show_projects(self, entities):
        try:
            projects = await self.zoho_client.get_projects(entities.get('date_filter'))
            return self.create_projects_card(projects)
        except Exception as e:
            return self.create_error_card(f"Error fetching projects: {str(e)}")

    async def handle_team_utilization(self, entities):
        try:
            utilization = await self.zoho_client.get_team_utilization(entities.get('team'))
            return self.create_utilization_card(utilization)
        except Exception as e:
            return self.create_error_card(f"Error fetching utilization: {str(e)}")

    async def handle_assign_task(self, entities):
        try:
            result = await self.zoho_client.assign_task(
                entities.get('task_id'), 
                entities.get('user_id')
            )
            return self.create_success_card("Task assigned successfully!")
        except Exception as e:
            return self.create_error_card(f"Error assigning task: {str(e)}")

    async def handle_schedule_meeting(self, entities):
        return self.create_meeting_card(entities)

    def create_tasks_card(self, tasks):
        task_items = []
        for task in tasks[:5]:
            task_items.append({
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {"type": "TextBlock", "text": task.get('name', 'Unknown Task'), "weight": "Bolder"},
                            {"type": "TextBlock", "text": f"Status: {task.get('status', 'Unknown')}", "size": "Small"}
                        ]
                    },
                    {
                        "type": "Column",
                        "width": "auto",
                        "items": [
                            {
                                "type": "ActionSet",
                                "actions": [
                                    {
                                        "type": "Action.Submit",
                                        "title": "Update",
                                        "data": {"action": "update_task", "task_id": task.get('id')}
                                    }
                                ]
                            }
                        ]
                    }
                ]
            })

        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "📋 Tasks", "weight": "Bolder", "size": "Medium"},
                *task_items
            ]
        }
        return self.format_adaptive_card(card)

    def create_projects_card(self, projects):
        project_items = []
        for project in projects[:5]:
            project_items.append({
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {"type": "TextBlock", "text": project.get('name', 'Unknown Project'), "weight": "Bolder"},
                            {"type": "TextBlock", "text": f"Due: {project.get('end_date', 'No due date')}", "size": "Small"}
                        ]
                    }
                ]
            })

        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "🚀 Projects", "weight": "Bolder", "size": "Medium"},
                *project_items
            ]
        }
        return self.format_adaptive_card(card)

    def create_utilization_card(self, utilization_data):
        util_items = []
        for member in utilization_data:
            util_items.append({
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {"type": "TextBlock", "text": member.get('member', 'Unknown'), "weight": "Bolder"},
                            {"type": "TextBlock", "text": f"Tasks: {member.get('tasks', 0)}", "size": "Small"}
                        ]
                    },
                    {
                        "type": "Column",
                        "width": "auto",
                        "items": [
                            {"type": "TextBlock", "text": member.get('utilization', '0%'), "weight": "Bolder", "color": "Good"}
                        ]
                    }
                ]
            })

        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "👥 Team Utilization", "weight": "Bolder", "size": "Medium"},
                *util_items
            ]
        }
        return self.format_adaptive_card(card)

    def create_meeting_card(self, entities):
        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "📅 Schedule Meeting", "weight": "Bolder", "size": "Medium"},
                {"type": "Input.Text", "id": "meeting_title", "placeholder": "Meeting Title"},
                {"type": "Input.Date", "id": "meeting_date"},
                {"type": "Input.Time", "id": "meeting_time"},
                {"type": "Input.Text", "id": "attendees", "placeholder": "Attendees (comma separated)"}
            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Schedule Meeting",
                    "data": {"action": "schedule_meeting"}
                }
            ]
        }
        return self.format_adaptive_card(card)

    def create_help_card(self):
        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "🤖 Teams Assistant", "weight": "Bolder", "size": "Medium"},
                {"type": "TextBlock", "text": "I can help you with:", "wrap": True},
                {"type": "TextBlock", "text": "• List all tasks", "wrap": True},
                {"type": "TextBlock", "text": "• Show projects due this month", "wrap": True},
                {"type": "TextBlock", "text": "• Team utilization reports", "wrap": True},
                {"type": "TextBlock", "text": "• Assign tasks to team members", "wrap": True},
                {"type": "TextBlock", "text": "• Schedule meetings", "wrap": True}
            ]
        }
        return self.format_adaptive_card(card)

    def create_success_card(self, message):
        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "✅ Success", "weight": "Bolder", "color": "Good"},
                {"type": "TextBlock", "text": message, "wrap": True}
            ]
        }
        return self.format_adaptive_card(card)

    def create_error_card(self, message):
        card = {
            "type": "AdaptiveCard",
            "version": "1.3",
            "body": [
                {"type": "TextBlock", "text": "❌ Error", "weight": "Bolder", "color": "Attention"},
                {"type": "TextBlock", "text": message, "wrap": True}
            ]
        }
        return self.format_adaptive_card(card)

    def format_adaptive_card(self, card):
        return {
            "type": "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": card
            }]
        }

bot = TeamsBot()

@app.route('/api/messages', methods=['POST'])
def messages():
    try:
        body = request.get_json()
        
        if body.get('type') == 'message':
            message_text = body.get('text', '')
            user_id = body.get('from', {}).get('id', '')
            
            # Run async function
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            response = loop.run_until_complete(bot.process_message(message_text, user_id))
            loop.close()
            
            return jsonify(response)
        
        return jsonify({"status": "ok"})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8000)))