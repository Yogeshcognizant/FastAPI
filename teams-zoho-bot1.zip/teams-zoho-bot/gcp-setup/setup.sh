#!/bin/bash
PROJECT_ID="teams-zoho-integration"
REGION="us-central1"

# Set project
gcloud config set project $PROJECT_ID

# Enable required APIs
gcloud services enable aiplatform.googleapis.com
gcloud services enable cloudfunctions.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable secretmanager.googleapis.com
gcloud services enable dialogflow.googleapis.com
gcloud services enable cloudbuild.googleapis.com

# Create service account
gcloud iam service-accounts create teams-bot-sa \
    --display-name="Teams Bot Service Account"

# Grant permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:teams-bot-sa@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/aiplatform.user"

gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:teams-bot-sa@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/secretmanager.secretAccessor"

# Create secrets (replace with actual values)
echo "your-zoho-client-id" | gcloud secrets create zoho-client-id --data-file=-
echo "your-zoho-client-secret" | gcloud secrets create zoho-client-secret --data-file=-
echo "your-teams-app-id" | gcloud secrets create teams-app-id --data-file=-
echo "your-teams-app-password" | gcloud secrets create teams-app-password --data-file=-
echo "your-sap-username" | gcloud secrets create sap-username --data-file=-
echo "your-sap-password" | gcloud secrets create sap-password --data-file=-

echo "GCP setup completed successfully!"