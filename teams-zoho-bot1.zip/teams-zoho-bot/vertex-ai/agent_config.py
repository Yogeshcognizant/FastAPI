from google.cloud import aiplatform
from google.cloud.aiplatform.gapic.schema import predict
import json

class VertexAIAgent:
    def __init__(self, project_id="teams-zoho-integration", location="us-central1"):
        self.project_id = project_id
        self.location = location
        aiplatform.init(project=project_id, location=location)
        
    def create_agent_config(self):
        """Create Vertex AI agent configuration"""
        agent_config = {
            "display_name": "Teams Zoho Integration Agent",
            "description": "AI agent for Microsoft Teams integration with Zoho Projects and SAP",
            "language_code": "en",
            "time_zone": "America/New_York",
            "intents": self._get_intents(),
            "entities": self._get_entities(),
            "flows": self._get_flows()
        }
        return agent_config
    
    def _get_intents(self):
        """Define intents for the agent"""
        return [
            {
                "display_name": "list_tasks",
                "training_phrases": [
                    "List all tasks",
                    "Show me my tasks", 
                    "What tasks do I have",
                    "Display tasks",
                    "Get task list"
                ],
                "parameters": [
                    {
                        "display_name": "filter",
                        "entity_type": "filter_type",
                        "is_list": False,
                        "required": False
                    }
                ]
            },
            {
                "display_name": "show_projects",
                "training_phrases": [
                    "Show projects",
                    "List projects",
                    "What projects are due this month",
                    "Display all projects",
                    "Get project list"
                ],
                "parameters": [
                    {
                        "display_name": "date_filter", 
                        "entity_type": "date_period",
                        "is_list": False,
                        "required": False
                    }
                ]
            },
            {
                "display_name": "team_utilization",
                "training_phrases": [
                    "Show team utilization",
                    "Team performance",
                    "Utilization of each team member",
                    "Team workload",
                    "Who is overloaded"
                ],
                "parameters": [
                    {
                        "display_name": "team",
                        "entity_type": "team_name",
                        "is_list": False,
                        "required": False
                    }
                ]
            },
            {
                "display_name": "assign_task",
                "training_phrases": [
                    "Assign task to user",
                    "Give this task to someone",
                    "Allocate task",
                    "Assign work"
                ],
                "parameters": [
                    {
                        "display_name": "task_id",
                        "entity_type": "task_identifier",
                        "is_list": False,
                        "required": True
                    },
                    {
                        "display_name": "user_id",
                        "entity_type": "user_name",
                        "is_list": False,
                        "required": True
                    }
                ]
            },
            {
                "display_name": "schedule_meeting",
                "training_phrases": [
                    "Schedule a meeting",
                    "Book meeting room",
                    "Set up meeting",
                    "Create calendar event"
                ],
                "parameters": [
                    {
                        "display_name": "meeting_title",
                        "entity_type": "meeting_subject",
                        "is_list": False,
                        "required": True
                    },
                    {
                        "display_name": "date_time",
                        "entity_type": "datetime",
                        "is_list": False,
                        "required": True
                    }
                ]
            }
        ]
    
    def _get_entities(self):
        """Define entities for the agent"""
        return [
            {
                "display_name": "filter_type",
                "kind": "KIND_MAP",
                "entities": [
                    {"value": "all", "synonyms": ["all", "everything", "complete"]},
                    {"value": "active", "synonyms": ["active", "ongoing", "current"]},
                    {"value": "completed", "synonyms": ["completed", "done", "finished"]},
                    {"value": "overdue", "synonyms": ["overdue", "late", "delayed"]}
                ]
            },
            {
                "display_name": "date_period",
                "kind": "KIND_MAP", 
                "entities": [
                    {"value": "today", "synonyms": ["today", "this day"]},
                    {"value": "this_week", "synonyms": ["this week", "current week"]},
                    {"value": "this_month", "synonyms": ["this month", "current month"]},
                    {"value": "next_month", "synonyms": ["next month", "following month"]}
                ]
            },
            {
                "display_name": "team_name",
                "kind": "KIND_MAP",
                "entities": [
                    {"value": "development", "synonyms": ["dev", "development", "developers"]},
                    {"value": "qa", "synonyms": ["qa", "testing", "quality assurance"]},
                    {"value": "design", "synonyms": ["design", "ui", "ux", "designers"]},
                    {"value": "all", "synonyms": ["all", "everyone", "entire team"]}
                ]
            }
        ]
    
    def _get_flows(self):
        """Define conversation flows"""
        return [
            {
                "display_name": "Default Start Flow",
                "description": "Main conversation flow",
                "pages": [
                    {
                        "display_name": "Start Page",
                        "entry_fulfillment": {
                            "messages": [
                                {
                                    "text": {
                                        "text": ["Hello! I'm your Teams assistant. I can help you with tasks, projects, team utilization, and scheduling meetings. What would you like to do?"]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        ]

class DialogflowCXManager:
    def __init__(self, project_id, location="us-central1"):
        self.project_id = project_id
        self.location = location
        
    async def create_agent(self, agent_config):
        """Create Dialogflow CX agent"""
        try:
            from google.cloud import dialogflowcx_v3 as dialogflow
            
            client = dialogflow.AgentsClient()
            parent = f"projects/{self.project_id}/locations/{self.location}"
            
            agent = dialogflow.Agent(
                display_name=agent_config["display_name"],
                description=agent_config["description"],
                default_language_code=agent_config["language_code"],
                time_zone=agent_config["time_zone"]
            )
            
            request = dialogflow.CreateAgentRequest(
                parent=parent,
                agent=agent
            )
            
            operation = client.create_agent(request=request)
            response = operation.result()
            
            print(f"Agent created: {response.name}")
            return response.name
            
        except Exception as e:
            print(f"Error creating agent: {e}")
            return None
    
    async def setup_intents(self, agent_name, intents):
        """Set up intents for the agent"""
        try:
            from google.cloud import dialogflowcx_v3 as dialogflow
            
            client = dialogflow.IntentsClient()
            
            for intent_config in intents:
                intent = dialogflow.Intent(
                    display_name=intent_config["display_name"],
                    training_phrases=[
                        dialogflow.Intent.TrainingPhrase(
                            parts=[dialogflow.Intent.TrainingPhrase.Part(text=phrase)]
                        ) for phrase in intent_config["training_phrases"]
                    ]
                )
                
                request = dialogflow.CreateIntentRequest(
                    parent=agent_name,
                    intent=intent
                )
                
                response = client.create_intent(request=request)
                print(f"Intent created: {response.name}")
                
        except Exception as e:
            print(f"Error creating intents: {e}")

# Usage example
async def setup_vertex_ai_agent():
    """Set up the complete Vertex AI agent"""
    agent_creator = VertexAIAgent()
    dialogflow_manager = DialogflowCXManager("teams-zoho-integration")
    
    # Create agent configuration
    config = agent_creator.create_agent_config()
    
    # Create the agent
    agent_name = await dialogflow_manager.create_agent(config)
    
    if agent_name:
        # Set up intents
        await dialogflow_manager.setup_intents(agent_name, config["intents"])
        print("Vertex AI agent setup completed successfully!")
    else:
        print("Failed to create Vertex AI agent")

if __name__ == "__main__":
    import asyncio
    asyncio.run(setup_vertex_ai_agent())