from google.cloud import aiplatform
import re
import json

class NLPProcessor:
    def __init__(self):
        try:
            aiplatform.init(project="teams-zoho-integration", location="us-central1")
        except Exception as e:
            print(f"Warning: Could not initialize Vertex AI: {e}")

    async def process_message(self, message):
        intent = await self.classify_intent(message)
        entities = await self.extract_entities(message)
        return intent, entities

    async def classify_intent(self, message):
        message_lower = message.lower()
        
        # Intent mapping with keywords
        intent_patterns = {
            "list_tasks": ["list", "show tasks", "tasks", "task list", "my tasks"],
            "show_projects": ["projects", "show projects", "project list", "due this month"],
            "team_utilization": ["utilization", "team utilization", "team performance", "workload"],
            "assign_task": ["assign", "assign task", "give task", "allocate"],
            "update_status": ["update", "change status", "mark complete", "progress"],
            "schedule_meeting": ["meeting", "schedule", "book meeting", "calendar"]
        }
        
        for intent, keywords in intent_patterns.items():
            for keyword in keywords:
                if keyword in message_lower:
                    return intent
        
        return "unknown"

    async def extract_entities(self, message):
        entities = {}
        message_lower = message.lower()
        
        # Date filters
        if "this month" in message_lower:
            entities["date_filter"] = "current_month"
        elif "this week" in message_lower:
            entities["date_filter"] = "current_week"
        elif "today" in message_lower:
            entities["date_filter"] = "today"
        
        # Team filters
        if "team" in message_lower:
            entities["team"] = "all"
        
        # Task ID extraction (simple pattern)
        task_id_match = re.search(r'task[:\s]+(\d+)', message_lower)
        if task_id_match:
            entities["task_id"] = task_id_match.group(1)
        
        # User mentions
        user_match = re.search(r'@(\w+)', message)
        if user_match:
            entities["user_id"] = user_match.group(1)
        
        # Priority extraction
        if "high" in message_lower:
            entities["priority"] = "high"
        elif "medium" in message_lower:
            entities["priority"] = "medium"
        elif "low" in message_lower:
            entities["priority"] = "low"
        
        return entities

    async def generate_response(self, intent, data):
        """Generate natural language response using Vertex AI"""
        try:
            # Simple template-based responses for now
            templates = {
                "list_tasks": f"Here are your tasks: {len(data)} items found",
                "show_projects": f"Found {len(data)} projects",
                "team_utilization": "Team utilization report generated",
                "assign_task": "Task assignment completed",
                "schedule_meeting": "Meeting scheduled successfully"
            }
            
            return templates.get(intent, "I've processed your request")
        
        except Exception as e:
            return f"Generated response for {intent}"

    async def analyze_sentiment(self, message):
        """Simple sentiment analysis"""
        positive_words = ["good", "great", "excellent", "perfect", "awesome"]
        negative_words = ["bad", "terrible", "awful", "horrible", "worst"]
        
        message_lower = message.lower()
        
        positive_count = sum(1 for word in positive_words if word in message_lower)
        negative_count = sum(1 for word in negative_words if word in message_lower)
        
        if positive_count > negative_count:
            return "positive"
        elif negative_count > positive_count:
            return "negative"
        else:
            return "neutral"